
export function detectCard(rect:any){
 const ratio = rect.width / rect.height
 if(ratio > 1.45 && ratio < 1.65){
  return true
 }
 return false
}
