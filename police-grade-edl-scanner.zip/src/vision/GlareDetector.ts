export function detectGlare(ratio:number){ return ratio < 0.05 }
