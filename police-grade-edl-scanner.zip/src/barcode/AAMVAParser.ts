
export function parseAAMVA(data:string){

 const fields:any = {}

 data.split('\n').forEach(line=>{
  const key = line.substring(0,3)
  const value = line.substring(3)
  fields[key] = value
 })

 return {
  firstName:fields['DAC'],
  lastName:fields['DCS'],
  licenseNumber:fields['DAQ'],
  dob:fields['DBB'],
  expiry:fields['DBA'],
  address:fields['DAG'],
  city:fields['DAI'],
  state:fields['DAJ']
 }

}
