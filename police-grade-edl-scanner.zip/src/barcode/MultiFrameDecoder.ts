
export function multiFrameDecode(frames:any[]){
 for(let i=0;i<frames.length;i++){
   const result = null
   if(result){
     return result
   }
 }
 return null
}
