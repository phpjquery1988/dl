
import {detectBlur} from '../vision/BlurDetector'
import {detectBrightness} from '../vision/BrightnessDetector'
import {detectGlare} from '../vision/GlareDetector'
import {detectCard} from '../vision/CardDetector'

export function framePipeline(frame:any){

 'worklet'

 const blurOk = detectBlur(130)
 const brightnessOk = detectBrightness(80)
 const glareOk = detectGlare(0.01)
 const cardDetected = detectCard({width:600,height:380})

 return {
  blurOk,
  brightnessOk,
  glareOk,
  cardDetected
 }

}
