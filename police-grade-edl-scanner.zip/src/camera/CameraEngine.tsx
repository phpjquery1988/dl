
import React from 'react'
import {Camera,useCameraDevices,useFrameProcessor} from 'react-native-vision-camera'
import {runOnJS} from 'react-native-reanimated'
import {framePipeline} from '../pipeline/FramePipeline'

export default function CameraEngine(){

 const devices = useCameraDevices()
 const device = devices.back

 const frameProcessor = useFrameProcessor((frame)=>{
   'worklet'
   const result = framePipeline(frame)
   if(result){
     runOnJS(console.log)(result)
   }
 },[])

 if(!device) return null

 return(
  <Camera
   style={{flex:1}}
   device={device}
   isActive={true}
   frameProcessor={frameProcessor}
   frameProcessorFps={15}
  />
 )

}
