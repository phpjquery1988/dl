
import React from 'react'
import {View,Text} from 'react-native'
import CameraEngine from '../camera/CameraEngine'
import OverlayFrame from './OverlayFrame'

export default function ScannerScreen(){
 return(
  <View style={{flex:1}}>
    <CameraEngine/>
    <OverlayFrame/>
    <View style={{position:'absolute',bottom:50,alignSelf:'center'}}>
      <Text style={{color:'#fff'}}>Align license inside frame</Text>
    </View>
  </View>
 )
}
