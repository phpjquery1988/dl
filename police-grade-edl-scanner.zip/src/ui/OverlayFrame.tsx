
import React from 'react'
import {View} from 'react-native'

export default function OverlayFrame(){
 return(
  <View style={{
   position:'absolute',
   top:'30%',
   width:'85%',
   alignSelf:'center',
   aspectRatio:1.586,
   borderWidth:3,
   borderColor:'#00E0FF'
  }}/>
 )
}
