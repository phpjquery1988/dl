
#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(CognexModule, NSObject)

RCT_EXTERN_METHOD(scanPDF417:(NSString*)imagePath
 resolver:(RCTPromiseResolveBlock)resolve
 rejecter:(RCTPromiseRejectBlock)reject)

@end
