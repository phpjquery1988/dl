
# Police‑Grade EDL Scanner (Advanced React Native Architecture)

This repository is a large production‑style scaffold for building a USA Driver License / EDL scanner.

Architecture includes:
- Vision Camera frame processor
- OpenCV card detection pipeline
- Perspective warp cropping
- Motion / blur / glare / brightness validation
- Auto capture engine
- Multi‑frame PDF417 decoding
- Cognex bridge
- AAMVA parser
- OCR fallback

NOTE:
OpenCV and Cognex SDK must be integrated manually due to licensing restrictions.
