
package com.edlscanner;

import com.facebook.react.bridge.*;

public class CognexModule extends ReactContextBaseJavaModule {

 public CognexModule(ReactApplicationContext context){
  super(context);
 }

 @Override
 public String getName(){
  return "CognexModule";
 }

 @ReactMethod
 public void scanPDF417(String imagePath, Promise promise){
  promise.resolve("PDF417_RESULT_PLACEHOLDER");
 }

}
