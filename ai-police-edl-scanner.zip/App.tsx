
import React from 'react'
import ScannerScreen from './src/ui/ScannerScreen'

export default function App(){
 return <ScannerScreen/>
}
