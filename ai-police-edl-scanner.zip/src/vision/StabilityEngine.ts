
let stable=0
export function isStable(diff:number){
 if(diff<2) stable++
 return stable>6
}
