
export function detectCard(rect:any){
 const ratio = rect.width/rect.height
 return ratio>1.45 && ratio<1.65
}
