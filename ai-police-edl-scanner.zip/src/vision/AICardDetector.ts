
export function aiCardDetector(frame:any){
 // Placeholder for TensorFlow Lite inference
 return false
}
