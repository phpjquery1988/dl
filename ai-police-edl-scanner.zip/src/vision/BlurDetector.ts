export function detectBlur(score:number){return score>120}
