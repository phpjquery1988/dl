
import {NativeModules} from 'react-native'
const {CognexModule}=NativeModules

export function scanPDF417(image:string){
 return CognexModule.scanPDF417(image)
}
