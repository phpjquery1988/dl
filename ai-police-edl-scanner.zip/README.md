
# AI Police‑Grade EDL Scanner (React Native)

Advanced architecture including:
- Vision Camera frame processor
- OpenCV card edge detection (placeholder)
- AI card detection hook (TensorFlow Lite)
- Perspective warp cropping
- Motion / blur / glare / brightness validation
- Auto capture engine
- Multi‑frame PDF417 scanning
- Cognex bridge
- AAMVA parser
- OCR fallback hooks

Native SDKs (OpenCV, Cognex, MLKit/TFLite) must be integrated manually.
