
import React from 'react'
import {View} from 'react-native'

export default function OverlayFrame(){
 return(
  <View style={{
   position:'absolute',
   top:'28%',
   alignSelf:'center',
   width:'85%',
   aspectRatio:1.586,
   borderWidth:3,
   borderColor:'#00E0FF',
   borderRadius:10
  }}/>
 )
}
