
import React from 'react'
import {Camera,useCameraDevices,useFrameProcessor} from 'react-native-vision-camera'
import {runOnJS} from 'react-native-reanimated'
import {processFrame} from '../vision/frameProcessor'

export default function CameraEngine(){

 const devices = useCameraDevices()
 const device = devices.back

 const frameProcessor = useFrameProcessor((frame)=>{
   'worklet'
   const result = processFrame(frame)
   if(result){
     runOnJS(console.log)(result)
   }
 },[])

 if(!device) return null

 return(
   <Camera
    style={{flex:1}}
    device={device}
    isActive={true}
    frameProcessor={frameProcessor}
    frameProcessorFps={10}
   />
 )

}
