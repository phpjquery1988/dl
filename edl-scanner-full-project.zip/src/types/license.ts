
export interface License{
 firstName:string
 lastName:string
 licenseNumber:string
 dob:string
 expiry:string
 address?:string
 city?:string
 state?:string
}
