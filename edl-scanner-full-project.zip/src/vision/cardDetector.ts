
export function detectCard(rect:any){
 const ratio = rect.width / rect.height
 if(ratio > 1.4 && ratio < 1.7){
  return true
 }
 return false
}
