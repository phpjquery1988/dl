
export function detectBrightness(mean:number){
 return mean > 60
}
