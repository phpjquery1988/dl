
let stableFrames = 0

export function checkStability(diff:number){

 if(diff < 2){
  stableFrames++
 }

 if(stableFrames > 6){
  return true
 }

 return false

}
