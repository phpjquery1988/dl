
export function processFrame(frame:any){

 'worklet'

 return {
   cardDetected:false,
   brightnessOk:true,
   blurScore:120
 }

}
