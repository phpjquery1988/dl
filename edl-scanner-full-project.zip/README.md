
# React Native EDL Scanner (Full Project Scaffold)

Features
- Vision Camera integration
- Frame Processor Plugin
- OpenCV card detection placeholder
- Perspective crop module
- Blur / glare / brightness detection
- Auto capture engine
- Cognex barcode bridge placeholder
- AAMVA parser

Setup
npm install
cd ios && pod install
npx react-native run-android
npx react-native run-ios
